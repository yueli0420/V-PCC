﻿Executable files for the Hierarchical Clustering based Tunable Coding Unit Division for Video-based Point Cloud Coding method, which is provided by Yue Li (liyue AT usc Dot edu Dot cn).

TAppEncoder_SI0, TAppEncoder_SI1, TAppEncoder_SI2, TAppEncoder_SI3, and TAppEncoder_SI4 respectively correspond to executable files in different similarity intervals in Table 3. These executable files are used to encode the geometry and attribute videos of V-PCC. Note that, other executable files used for V-PCC configuration have not changed, such as PccAppEncoder, PccAppMetrics, etc.

